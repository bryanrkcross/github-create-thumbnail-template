var grunt = require('grunt');
grunt.loadNpmTasks('grunt-aws-lambda');

grunt.initConfig({
   lambda_invoke: {
      default: {
         options: {
            file_name: 'index.js'
         }
      }
   },
   lambda_deploy: {
      default: {
         arn: 'arn:aws:lambda:ap-southeast-2:377117578606:function:CreateThumbnail',
         options: {
             region: 'ap-southeast-2'
         }
      }
   },
   lambda_package: {
      default: {
         options: {
            include_time: false,
            include_version: false
         }
   }
   }
});

grunt.registerTask('deploy', ['lambda_package', 'lambda_deploy'])
